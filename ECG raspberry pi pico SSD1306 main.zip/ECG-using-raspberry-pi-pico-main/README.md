# ECG-using-raspberry-pi-pico
Implemented using raspberry pi pico and AD8232 ecg sensor 

Micropython is used as programming language and Thonny as IDE

Components:
<ul>
      <li>Raspberry Pi Pico W</li>
      <li>AD8232 ECG sensor</li>
      <li>OLED (SSD1306)</li>
      <li>Lead Electrodes</li>
</ul>
